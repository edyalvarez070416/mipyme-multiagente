const express = require('express');
const path = require('path');
const app = express();
const PDFDocument = require('pdfkit'); 

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Arriba en server.js
const {
  ejecutarAgenteHermes,
  ejecutarAgenteConfigurador,
  reiniciarSesion
} = require("./agentsOnboarding");

// 1. Conversar con Hermes en el onboarding
app.post("/api/agentes/hermes", async (req, res) => {
  const { sessionId, mensaje } = req.body;
  const resultado = await ejecutarAgenteHermes(sessionId, mensaje);
  res.json(resultado); 
});

// 2. Generar el JSON del Agente Configurador (para los 3 prediseños de Xcode)
app.post("/api/agentes/configurar", async (req, res) => {
  const { sessionId, transcripcion } = req.body;
  const resultado = await ejecutarAgenteConfigurador(sessionId, transcripcion);
  res.json(resultado);
});

// 3. Reiniciar entrevista para mostrar otro perfil de negocio en la demo
app.post("/api/agentes/reiniciar", (req, res) => {
  const { sessionId } = req.body;
  reiniciarSesion(sessionId);
  res.json({ ok: true, mensaje: "Sesión reiniciada" });
});
// URL donde correrás el repo portfedh/codi-api
const CODI_API_URL = process.env.CODI_API_URL || 'http://localhost:3000';

// Almacén en memoria para el MVP de hackathon
const ventas = new Map();

// 1. Crear orden de cobro y solicitar payload QR a codi-api
app.post('/api/cobros', async (req, res) => {
  const { producto, cantidad, precioUnitario, comprador, clabe, negocio } = req.body;
  const total = Number(cantidad) * Number(precioUnitario);
  const referencia = `VTA-${Date.now().toString().slice(-6)}`;

  let qrPayload = JSON.stringify({
    tipo: 'CODI_QR',
    referencia,
    monto: total.toFixed(2),
    clabeDestino: clabe,
    beneficiario: negocio || 'Comercio MiPyme'
  });

  // Intentar conectar con el microservicio portfedh/codi-api si está encendido
  try {
    const response = await fetch(`${CODI_API_URL}/api/codi/qr`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        monto: total,
        referencia,
        concepto: `${cantidad}x ${producto}`,
        clabeDestino: clabe
      })
    });
    if (response.ok) {
      const data = await response.json();
      if (data.qrString || data.payload) {
        qrPayload = data.qrString || data.payload;
      }
    }
  } catch (err) {
    // Si codi-api aún no está levantado, continúa con el payload estructurado local
    console.log('Aviso: usando payload QR estructurado local (codi-api no respondió en', CODI_API_URL, ')');
  }

  const venta = {
    referencia,
    negocio: negocio || 'Abarrotes La Esperanza',
    clabe,
    producto,
    cantidad: Number(cantidad),
    precioUnitario: Number(precioUnitario),
    total,
    comprador: comprador || 'Público en general',
    estatus: 'PENDIENTE',
    qrPayload,
    claveRastreo: null,
    fechaCreacion: new Date().toLocaleString('es-MX'),
    fechaLiquidacion: null
  };

  ventas.set(referencia, venta);
  res.json(venta);
});

// 2. Consultar estado de la venta (usado por el frontend para detectar el abono)
app.get('/api/cobros/:referencia', (req, res) => {
  const venta = ventas.get(req.params.referencia);
  if (!venta) return res.status(404).json({ error: 'Orden no encontrada' });
  res.json(venta);
});

// 3. WEBHOOK OFICIAL: Aquí pega portfedh/codi-api (o el simulador) cuando el pago se liquida
app.post('/api/webhooks/codi', (req, res) => {
  const { referencia, estatus, claveRastreo } = req.body;
  const venta = ventas.get(referencia);

  if (!venta) {
    return res.status(404).json({ error: 'Referencia no encontrada' });
  }

  if (estatus === 'LIQUIDADO' || estatus === 'COMPLETADO') {
    venta.estatus = 'LIQUIDADO';
    venta.claveRastreo = claveRastreo || `CODI${Date.now()}MXN`;
    venta.fechaLiquidacion = new Date().toLocaleString('es-MX');
    ventas.set(referencia, venta);
  }

  res.json({ recibido: true, venta });
});

// Agregar justo antes de app.listen(3000, ...) en server.js


app.get('/api/tickets/:referencia/pdf', (req, res) => {
  const venta = ventas.get(req.params.referencia);
  if (!venta) {
    return res.status(404).send('Ticket no encontrado');
  }

  const doc = new PDFDocument({
    size: [226, 420], // Formato ticket térmico ~80mm de ancho
    margins: { top: 16, bottom: 16, left: 14, right: 14 }
  });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="Ticket_${venta.referencia}.pdf"`);
  doc.pipe(res);

  const clabeUltimos4 = String(venta.clabe || '').slice(-4) || '----';
  const totalFmt = Number(venta.total || 0).toLocaleString('es-MX', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const unitFmt = Number(venta.precioUnitario || 0).toLocaleString('es-MX', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  // Encabezado del negocio
  doc
    .font('Helvetica-Bold')
    .fontSize(12)
    .text(String(venta.negocio || 'Comercio MiPyME'), { align: 'center' });

  doc
    .font('Helvetica')
    .fontSize(8)
    .fillColor('#475569')
    .text('COMPROBANTE DE VENTA DIGITAL (CoDi)', { align: 'center' })
    .moveDown(0.5);

  doc
    .moveTo(14, doc.y)
    .lineTo(212, doc.y)
    .strokeColor('#cbd5e1')
    .stroke()
    .moveDown(0.5);

  // Datos de la operación
  doc.fillColor('#0f172a').fontSize(8.5);
  doc.font('Helvetica-Bold').text('Folio: ', { continued: true }).font('Helvetica').text(venta.referencia);
  doc.font('Helvetica-Bold').text('Estatus: ', { continued: true }).font('Helvetica').text(venta.estatus || 'PENDIENTE');
  doc.font('Helvetica-Bold').text('Fecha: ', { continued: true }).font('Helvetica').text(venta.fechaLiquidacion || venta.fechaCreacion || '');
  doc.font('Helvetica-Bold').text('Cliente: ', { continued: true }).font('Helvetica').text(venta.comprador || 'Público en general');
  doc.font('Helvetica-Bold').text('Destino: ', { continued: true }).font('Helvetica').text(`CLABE •••• ${clabeUltimos4}`);

  doc.moveDown(0.5);
  doc
    .moveTo(14, doc.y)
    .lineTo(212, doc.y)
    .strokeColor('#cbd5e1')
    .stroke()
    .moveDown(0.5);

  // Detalle del producto
  doc.font('Helvetica-Bold').text(`${venta.cantidad} x ${venta.producto}`);
  doc.font('Helvetica').fillColor('#475569').text(`P. Unitario: $${unitFmt} MXN`);
  doc.moveDown(0.5);

  // Total destacado
  doc
    .fillColor('#0f172a')
    .font('Helvetica-Bold')
    .fontSize(11)
    .text(`TOTAL PAGADO: $${totalFmt} MXN`);

  doc.moveDown(0.6);
  doc
    .font('Helvetica')
    .fontSize(7.5)
    .fillColor('#475569')
    .text('Método: CoDi / Transferencia SPEI (0% comisión)')
    .text(`Rastreo: ${venta.claveRastreo || 'Pendiente de liquidación'}`)
    .moveDown(0.8);

  doc
    .font('Helvetica-Bold')
    .fontSize(8.5)
    .fillColor('#0f172a')
    .text('¡Gracias por su compra!', { align: 'center' });

  doc.end();
});

app.listen(3000, () => {
  console.log('App de cobro CoDi corriendo en http://localhost:3000');
});