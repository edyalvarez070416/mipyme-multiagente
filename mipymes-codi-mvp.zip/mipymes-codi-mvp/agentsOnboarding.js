// agentsOnboarding.js
// Agente 1: Hermes (Entrevistador NLP)
// Agente 2: Configurador (Selector de prediseño y visibilidad de módulos en JSON estricto)

const NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1/chat/completions";
const NVIDIA_API_KEY = process.env.NVIDIA_API_KEY || "";

// Almacén temporal en memoria por sesión (ideal para demo en vivo)
const sesiones = new Map();

// ============================================================================
// PROMPTS DE LOS DOS AGENTES
// ============================================================================

const PROMPT_HERMES = `
Eres HERMES, el asistente de bienvenida inteligente de una aplicación financiera y operativa para MiPyMEs en México.
Tu único trabajo en esta etapa es entrevistar brevemente al dueño o dueña del negocio en español natural, cálido y directo (máximo 2 oraciones por turno).

Debes descubrir en máximo 3 intercambios:
1. Qué tipo o giro de negocio tiene (ej. tienda/abarrotes, comida/cafetería, o servicios como estética/taller/consultorio) y cómo se llama si quiere decirlo.
2. Si maneja productos físicos y quiere registrar su inventario en menos de 10 minutos (o si no usa inventario).
3. Cuánto ingresa aproximadamente a la semana o al mes, y qué es lo que más le urge resolver hoy (cobrar rápido, controlar inventario o llevar cuentas).

Reglas:
- Haz solo 1 o 2 preguntas concretas por mensaje. No des listas largas ni discursos.
- Cuando ya tengas suficiente información sobre giro, uso de inventario e ingresos aproximados, cierra amablemente diciendo que ya tienes todo listo para armar su aplicación.
`.trim();

const PROMPT_CONFIGURADOR = `
Eres el AGENTE CONFIGURADOR de arquitectura de interfaz para una app móvil iOS (SwiftUI) de MiPyMEs en México.
Recibirás la transcripción de la entrevista inicial entre Hermes y el usuario.

Tu tarea es analizar las respuestas y devolver ÚNICAMENTE un objeto JSON válido (sin texto extra, sin bloques \`\`\`json) con exactamente esta estructura:

{
  "predisenoId": "comercio_inventario | servicios_rapidos | alimentos_mostrador",
  "negocio": {
    "nombre": "string",
    "giro": "string",
    "ingresoMetaMXN": number,
    "periodicidadMeta": "semanal | mensual"
  },
  "modulosVisibles": {
    "mostrarInventario": boolean,
    "mostrarEscanerRecibos": boolean,
    "mostrarCobroQR": boolean,
    "mostrarTicketPDF": boolean,
    "mostrarAsistenteVentasNLP": boolean,
    "mostrarMetaIngresos": boolean
  },
  "ordenTarjetasHome": ["string"],
  "mensajeBienvenida": "string"
}

Reglas de decisión estrictas:
1. "predisenoId":
   - Usa "comercio_inventario" si vende productos físicos, abarrotes, ropa, papelería o quiere registrar inventario en menos de 10 minutos.
   - Usa "servicios_rapidos" si da servicios (taller, estética, consultorio, reparaciones, freelance) o indica que NO maneja inventario.
   - Usa "alimentos_mostrador" si es comida, taquería, cafetería, fonda o venta rápida en mostrador.
2. Si el usuario dice que NO necesita inventario o es un negocio de servicios puros:
   - Pon "mostrarInventario": false y "mostrarEscanerRecibos": false (en SwiftUI se ocultan, no se eliminan).
3. "ordenTarjetasHome" solo puede contener valores de esta lista según las prioridades del usuario:
   ["escaner_recibos", "inventario", "cobro_qr", "asistente_nlp", "meta_ingresos", "ticket_pdf"]
4. "ingresoMetaMXN": extrae el número mencionado (si dice "15 mil", pon 15000). Si no dijo monto, pon 15000 por defecto.
5. "mensajeBienvenida": 1 oración corta explicando qué módulos activaste y qué ocultaste para simplificarle la pantalla.
`.trim();

// ============================================================================
// HELPER DE LLAMADA A NVIDIA NIM
// ============================================================================

async function llamarNvidiaNIM({ model, messages, temperature = 0.5, jsonMode = false }) {
  if (!NVIDIA_API_KEY) {
    throw new Error("SIN_API_KEY");
  }

  const body = {
    model,
    messages,
    temperature,
    max_tokens: 600
  };

  if (jsonMode) {
    body.response_format = { type: "json_object" };
  }

  const response = await fetch(NVIDIA_BASE_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${NVIDIA_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`NVIDIA NIM error ${response.status}: ${errText}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

// ============================================================================
// AGENTE 1: HERMES (ENTREVISTA INICIAL)
// ============================================================================

async function ejecutarAgenteHermes(sessionId = "default", mensajeUsuario = "") {
  let sesion = sesiones.get(sessionId);
  if (!sesion) {
    sesion = {
      historial: [{ role: "system", content: PROMPT_HERMES }],
      turnosUsuario: 0
    };
    sesiones.set(sessionId, sesion);
  }

  // Primer saludo automático si entra vacío
  if (!mensajeUsuario.trim() && sesion.turnosUsuario === 0) {
    const saludoInicial =
      "¡Hola! Soy Hermes. Para armar tu app a la medida: ¿qué tipo de negocio tienes y te gustaría registrar tu inventario aquí en menos de 10 minutos?";
    sesion.historial.push({ role: "assistant", content: saludoInicial });
    return {
      agente: "Hermes",
      sessionId,
      turno: 0,
      listoParaConfigurar: false,
      respuesta: saludoInicial
    };
  }

  sesion.turnosUsuario += 1;
  sesion.historial.push({ role: "user", content: mensajeUsuario.trim() });

  // Si ya respondió 3 veces, cerramos entrevista para pasar al Agente Configurador
  if (sesion.turnosUsuario >= 3) {
    const cierre =
      "¡Perfecto! Ya entendí cómo opera tu negocio. Paso tus respuestas al Agente Configurador para personalizar tu pantalla.";
    sesion.historial.push({ role: "assistant", content: cierre });
    return {
      agente: "Hermes",
      sessionId,
      turno: sesion.turnosUsuario,
      listoParaConfigurar: true,
      respuesta: cierre
    };
  }

  try {
    const respuestaIA = await llamarNvidiaNIM({
      model: "meta/llama-3.1-70b-instruct",
      messages: sesion.historial,
      temperature: 0.6,
      jsonMode: false
    });

    sesion.historial.push({ role: "assistant", content: respuestaIA });

    return {
      agente: "Hermes",
      sessionId,
      turno: sesion.turnosUsuario,
      listoParaConfigurar: sesion.turnosUsuario >= 2 && respuestaIA.toLowerCase().includes("listo"),
      respuesta: respuestaIA
    };
  } catch (error) {
    // Respaldo instantáneo si no hay API key o falla la red en el evento
    const fallbackPregunta =
      sesion.turnosUsuario === 1
        ? "¿Cuánto ingresas aproximadamente a la semana o al mes, y qué te urge más controlar hoy: inventario, ventas o cobros?"
        : "¡Excelente! Con eso tengo todo listo para configurar tu app a la medida.";

    sesion.historial.push({ role: "assistant", content: fallbackPregunta });

    return {
      agente: "Hermes",
      sessionId,
      turno: sesion.turnosUsuario,
      listoParaConfigurar: sesion.turnosUsuario >= 2,
      respuesta: fallbackPregunta,
      modoRespaldo: true
    };
  }
}

// ============================================================================
// AGENTE 2: CONFIGURADOR (GENERACIÓN DE JSON PARA XCODE / SWIFTUI)
// ============================================================================

function generarConfigFallback(transcripcion) {
  const t = transcripcion.toLowerCase();

  const sinInventario =
    t.includes("no uso inventario") ||
    t.includes("sin inventario") ||
    t.includes("no tengo inventario") ||
    t.includes("no ocupo inventario") ||
    t.includes("servicio") ||
    t.includes("estética") ||
    t.includes("taller") ||
    t.includes("consultorio");

  const esComida =
    t.includes("comida") ||
    t.includes("taco") ||
    t.includes("café") ||
    t.includes("cafe") ||
    t.includes("fonda") ||
    t.includes("restaurante");

  const predisenoId = sinInventario
    ? "servicios_rapidos"
    : esComida
    ? "alimentos_mostrador"
    : "comercio_inventario";

  const esMensual = t.includes("mes") || t.includes("mensual");
  const matchNumero = transcripcion.match(/(\d[\d,.]*)/);
  let monto = 15000;
  if (matchNumero) {
    const raw = Number(matchNumero[1].replace(/,/g, ""));
    monto = t.includes("mil") && raw < 1000 ? raw * 1000 : raw;
  }

  const mostrarInventario = !sinInventario;

  return {
    predisenoId,
    negocio: {
      nombre: "Mi Negocio",
      giro: sinInventario ? "servicios" : esComida ? "alimentos_y_bebidas" : "comercio",
      ingresoMetaMXN: monto,
      periodicidadMeta: esMensual ? "mensual" : "semanal"
    },
    modulosVisibles: {
      mostrarInventario,
      mostrarEscanerRecibos: mostrarInventario,
      mostrarCobroQR: true,
      mostrarTicketPDF: true,
      mostrarAsistenteVentasNLP: true,
      mostrarMetaIngresos: true
    },
    ordenTarjetasHome: mostrarInventario
      ? ["escaner_recibos", "inventario", "cobro_qr", "asistente_nlp", "meta_ingresos", "ticket_pdf"]
      : ["cobro_qr", "asistente_nlp", "meta_ingresos", "ticket_pdf"],
    mensajeBienvenida: mostrarInventario
      ? "Activamos el escáner de recibos con visión e inventario rápido junto con tus cobros QR."
      : "Ocultamos inventario para dejar tu pantalla limpia y enfocada en cobros QR, ventas y tickets PDF."
  };
}

async function ejecutarAgenteConfigurador(sessionId = "default", transcripcionManual = "") {
  const sesion = sesiones.get(sessionId);
  const transcripcion =
    transcripcionManual.trim() ||
    (sesion
      ? sesion.historial
          .filter((m) => m.role !== "system")
          .map((m) => `${m.role === "user" ? "Usuario" : "Hermes"}: ${m.content}`)
          .join("\n")
      : "");

  try {
    const rawJson = await llamarNvidiaNIM({
      model: "meta/llama-3.1-70b-instruct",
      messages: [
        { role: "system", content: PROMPT_CONFIGURADOR },
        {
          role: "user",
          content: `Transcripción de la entrevista:\n${transcripcion}\n\nGenera el JSON de configuración:`
        }
      ],
      temperature: 0.1,
      jsonMode: true
    });

    const parsed = JSON.parse(rawJson);
    return {
      agente: "Configurador",
      sessionId,
      configuracion: parsed
    };
  } catch (error) {
    return {
      agente: "Configurador",
      sessionId,
      configuracion: generarConfigFallback(transcripcion),
      modoRespaldo: true
    };
  }
}

function reiniciarSesion(sessionId = "default") {
  sesiones.delete(sessionId);
}

module.exports = {
  ejecutarAgenteHermes,
  ejecutarAgenteConfigurador,
  reiniciarSesion
};